﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace YorubaTranslation
{
    public partial class About : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLoad_Click(object sender, EventArgs e)
        {
            if (txtEnglish.Text != "" && ddlSpeech.Text != "" && txtYoruba.Text != "")
            {
                AddWord wd = new AddWord(txtEnglish.Text, ddlSpeech.Text, txtYoruba.Text);
                wd.AddNewOtherWord();
                txtEnglish.Text = "";
                txtYoruba.Text = "";
            }
        }

        protected void btnEnter_Click(object sender, EventArgs e)
        {
            if (txtEWord.Text != "" &&  txtYWord.Text != "")
            {
                AddWord wd = new AddWord(txtEWord.Text, txtYWord.Text);
                wd.AddGroupedWord(ddlFileName.Text);
                txtEnglish.Text = "";
                txtYoruba.Text = "";
            }
        }
    }
}
