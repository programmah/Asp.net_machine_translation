﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace YorubaTranslation
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnTranslator_Click(object sender, EventArgs e)
        {
            Translator t = new Translator(txtEnglish.Value.Trim());
            txtYoruba.Value = t.TranslateEachWord();
            //string[] Phrase = t.reOrderDeterminant(txtEnglish.Value.Trim().Split(' '));
            //for (int i = 0; i < Phrase.Length; i++) //(string s in Phrase)
            //{
            //    Response.Write(Phrase[i]);
            //}
            //Dictionary<string, string> all_WordPair = t.getDataSet("dictionary.txt");
            //List<WordSet> allWordPair = t.disectWord(all_WordPair);

            //txtYoruba.Value = allWordPair.Where(W =>W.PartOfSpeech == "v").Count().ToString();
            
        }
    }
}
